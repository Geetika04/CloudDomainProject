fetch('books.json')
  .then(response => response.json())
  .then(data => {
    let container = document.getElementById('booklist');
    data.forEach(book => {
      container.innerHTML += `
        <div class="book-card">
          <img src="images/${book.image}" alt="${book.title}" />
          <h3>${book.title}</h3>
          <p><strong>Author:</strong> ${book.author}</p>
          <p><strong>Price:</strong> ₹${book.price}</p>
        </div>`;
    });
  })
  .catch(err => console.error('Error loading data:', err));